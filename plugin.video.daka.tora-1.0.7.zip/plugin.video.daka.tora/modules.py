# -*- coding: utf-8 -*-
import urllib,urllib2,sys,re,xbmcplugin,xbmcgui,xbmcaddon,xbmc,os

from variables import *
from shared_modules import *
if "plugin." in addonID: from shared_modules3 import *


'''---------------------------'''
	
def CATEGORIES():
	'''------------------------------
	---MAIN--------------------------
	------------------------------'''
	try: General_Language = getsetting('General_Language')
	except: General_Language = systemlanguage
	
	
	addDir("שיעורי תורה",'',101,"http://sfile.f-static.com/image/users/333706/ftp/my_files/%D7%A9%D7%99%D7%A2%D7%95%D7%A8%D7%99%20%D7%AA%D7%95%D7%A8%D7%94.png?id=21881047&sopC=1429703103924",'','1',0,getAddonFanart(101, default="https://i.ytimg.com/vi/P2U3N7a1VRY/maxresdefault.jpg", urlcheck_=True)) 
	addDir("דף היומי",'',102,'http://daf-yomi.com/Data/UploadedFiles/Books/71-sImg.jpg','','1',0,getAddonFanart(102, default="https://i.ytimg.com/vi/or6OGZRtKJs/maxresdefault.jpg", urlcheck_=True)) 
	addDir("שמירת הברית",'',104,'https://i.ytimg.com/vi/azxvKY-gfv8/hqdefault.jpg','','1',2, getAddonFanart(104, default="https://image.winudf.com/1162/017b567b14f52bce/screen-6.jpeg", urlcheck_=True)) 



def CATEGORIES101(name, iconimage, desc, fanart):
	background = 101
	background2 = fanart
	
	list = []
	list.append('&youtube_ch=UC9CQLewfvzEMrH5DcIj6ejw')
	addDir("תשובה באהבה",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=UC9CQLewfvzEMrH5DcIj6ejw',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []
	list.append('&youtube_ch=breslevtube')
	addDir("ברסלב",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=breslevtube',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []
	list.append('&youtube_ch=hidabrootTVChannel')
	addDir("הידברות HD",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=hidabrootTVChannel',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
	list = []
	list.append('&youtube_ch=hidabrooTeem')
	addDir("הידברות HD",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=hidabrooTeem',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
	list = []
	list.append('&youtube_ch=Hidabroot1')
	addDir("הידברות",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=Hidabroot1',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []#רביבו
	list.append('&youtube_pl=PLuH2hTdpWoUikWyRX9KiFuOM3AX33U86g')
	addDir("שיעורי תורה-הרב פיש",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUikWyRX9KiFuOM3AX33U86g',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []
	list.append('&youtube_ch=youtubanenu')
	addDir("הרב מיכאל לסרי",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=youtubanenu',0,getAddonFanart(background, default='getAPIdata', custom=""))
 
	list = []
	list.append('&youtube_ch=RabbiYosefMizrachHeb')
	addDir("הרב יוסף מזרחי",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=RabbiYosefMizrachHeb',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []
	list.append('&youtube_ch=UCAYi-3eZXoDAzejzBjsY5FA')
	addDir("הרב ברוך גזהיי",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=UCAYi-3eZXoDAzejzBjsY5FA',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
	list = []
	list.append('&youtube_ch=UCd5JBvz8SDaS4L_WQYyQMSQ')
	addDir("עולם התורה",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=UCd5JBvz8SDaS4L_WQYyQMSQ',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []
	list.append('&youtube_ch=isaharbe')
	addDir("למען שמו באהבה",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=isaharbe',0,getAddonFanart(background, default='getAPIdata', custom=""))

	list = []
	list.append('&youtube_ch=UCOcvoiaSh36IDm9FyJBJoBw')
	addDir("ברוך השם",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=UCOcvoiaSh36IDm9FyJBJoBw',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
	list = []
	list.append('&youtube_ch=UCIGLyVKzUvrQSu13xg26E-Q')
	addDir("מתוק מדבש-שיעורים בזוהר",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=UCIGLyVKzUvrQSu13xg26E-Q',0,getAddonFanart(background, default='getAPIdata', custom=""))

	
def CATEGORIES102(name, iconimage, desc, fanart):
	background = 102
	background2 = fanart
	
	
	list = []
	list.append('&youtube_ch=UCvN2Sx3pTOFBdi3RXOo8S1Q')
	addDir("דרשו ד ועוזו",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=UCvN2Sx3pTOFBdi3RXOo8S1Q',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
	list = []
	list.append('&youtube_ch=hasulammedia')
	addDir("בסולם קבלה ופנימיות",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_ch=hasulammedia',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
def CATEGORIES104(name, iconimage, desc, fanart):
	background = 104
	background2 = fanart
	
	fanart = '' #גדול
	thumb = '' #בינוני
	list = []
	
	list.append('&youtube_pl=PLuH2hTdpWoUg1O9zOwDV4WqyLvye9-2uM')
	addDir("שמירת הברית",list,17,'getAPIdata','getAPIdata','&getAPIdata=&youtube_pl=PLuH2hTdpWoUg1O9zOwDV4WqyLvye9-2uM',0,getAddonFanart(background, default='getAPIdata', custom=""))
	
	
